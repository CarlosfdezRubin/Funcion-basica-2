/*
 * File:   Main.c
 * Author: SEA - Aitor VA
 * D.E.P. - GiTELE - 2019-2020
 */

/* 
 * File:   Main.c
 * Author: AVA

 */

/* Este proyecto tiene como objetivo proveer los archivos base y la estructura
 * T�pica de programaci�n para usar durante la asignatura. L�ease con atenci�n
 * las recomendaciones y las instrucciones de uso.
 */

// SIEMPRE SE INCLUIR�N ESTOS ARCHIVOS DE CABECERA:
#include "Config.h"
#include "Main.h"
#include "Func.h"
#include "dsp.h"



//---------------------------------------------------------------------------
// Global variables
float duty=0.5;
    /* Variables externas generadas con la toolbox FilterDesigner de MatLab */
extern FIRStruct pasobandacarlosFilter; //Archivo .s

   	
unsigned int posicion=0;
float rms_sen,max_sen,med_sen; //Valores de RMS, valores m�ximos y medios para las dos se�ales
float rms_tri,max_tri,med_tri;
fractional senoidal[MUESTRAS];
fractional filtrada_sen[MUESTRAS];//Senoidal filtrada
fractional triangular[MUESTRAS]; 
fractional filtrada_tri[MUESTRAS];//Triangular filtrada

//---------------------------------------------------------------------------
// En este espacio pueden declararse las variables globales o las constantes.
// Ejemplo:
// unsigned int MiValor = 0;


//---------------------------------------------------------------------------
// ISR routine
//---------------------------------------------------------------------------

// Llamada a la subrutina de interrupci�n. Descomentar estas l�neas para activarla.
// Debe incluirse el nombre de la rutina de interrupci�n (vector de interrupci�n).
// Esta llamada a la funci�n de interrupci�n debe repetirse tantas veces como
// vectores de interrupci�n haya (cada una, con su vector correspondiente)

void __attribute__((interrupt, auto_psv)) _ADCInterrupt(void)
{
    IFS0bits.ADIF=0;        //Limpiar el flap

        if (posicion < MUESTRAS){
    //Se�ales filtradas
         
        senoidal[posicion] = (fractional)ADCBUFB;    
        FIR (MUESTRAS, &filtrada_sen, &senoidal, &pasobandacarlosFilter); //Llamamos a la rutina de Filtro
        triangular[posicion] = (fractional)ADCBUFA;    
        FIR (MUESTRAS, &filtrada_tri, &triangular, &pasobandacarlosFilter); //Llamamos a la rutina de Filtro
        posicion++;
  	
        }
    if(posicion>MUESTRAS)
            posicion=0;
    
    //ADC ON
    ADCON1bits.ADON=1; 
    
//    posicion++;
//    if(posicion>MUESTRAS)
//        posicion=0;

        }
void __attribute__((interrupt, auto_psv)) _T1Interrupt(void)
{
        
    IFS0bits.T1IF = 0;
    T1CONbits.TON = 0;
    
    TMR1 = 0;     //Limpio registro
    
    InitLCD();
    
    //Variables a mostrar
    rms_sen= RMS(senoidal, MUESTRAS);
    max_sen= Maximo(senoidal, MUESTRAS);
    med_sen= valorMedio(senoidal, MUESTRAS);
    
    rms_tri= RMS(triangular, MUESTRAS);
    max_tri= Maximo(triangular, MUESTRAS);
    med_tri= valorMedio(triangular, MUESTRAS);
    
    
    
    
    MostrarLCD(rms_sen, max_sen, med_sen, rms_tri, max_tri, med_tri);
   
    T1CONbits.TON = 1;  //Arrancar TMR1
}

//---------------------------------------------------------------------------
// Main routine
//---------------------------------------------------------------------------

// Funci�n principal. Siempre incluye un bucle infinito.

int main (void)
{   InitIO();
    // Aqu� se declarar�an las variables LOCALES a la funci�n Main.
    GenPwm(duty);
    FIRDelayInit (&pasobandacarlosFilter); 
    InitTMR1();
    InitTMR3();
    InitADC();
    ConfigInt();
    InitLCD();
    
    T1CONbits.TON=1;    //TMR1 ON
    T2CONbits.TON=1;  //TMR2 ON
    T3CONbits.TON=1;  //TMR3 ON
    
    
    while (1)   // bucle infinito
    {
   
    }
    
    return 0;
    
}// Main
